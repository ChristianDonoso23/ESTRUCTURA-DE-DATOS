#include <iostream>
#include <conio.h>
#include <windows.h>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <string>
#include "Juego.h"

using namespace std;

const char Juego::EMPTY = ' ';

Juego::Juego() {
    adjustToConsoleSize();
    board = vector<vector<char>>(HEIGHT, vector<char>(WIDTH, EMPTY));
    initializeBoard();
}

void Juego::adjustToConsoleSize() {
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    int columns, rows;

    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
    columns = csbi.srWindow.Right - csbi.srWindow.Left + 1;
    rows = csbi.srWindow.Bottom - csbi.srWindow.Top + 1;

    WIDTH = columns - 2;
    HEIGHT = rows - 2; 
}

void Juego::gotoxySimple(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void Juego::initializeBoard() {
    for (int i = 0; i < HEIGHT; ++i) {
        char* row = board.data()->data() + (i * WIDTH);
        for (int j = 0; j < WIDTH; ++j) {
            *(row + j) = EMPTY;
        }
    }
}

void Juego::printBoard() {
    gotoxySimple(0, 0);
    for (int i = 0; i < HEIGHT; ++i) {
        cout << "|";
        char* row = board.data()->data() + (i * WIDTH);
        for (int j = 0; j < WIDTH; ++j) {
            cout << *(row + j);
        }
        cout << "|" << endl;
    }
    cout << string(WIDTH + 2, '-') << endl;
}

bool Juego::checkCollision(int x, int y) {
    return y >= HEIGHT || x >= WIDTH || x < 0 || *(board.data()->data() + (y * WIDTH) + x) != EMPTY;
}

void Juego::mergePiece(char piece, int x, int y) {
    if (y < HEIGHT && x < WIDTH) {
        char* row = board.data()->data() + (y * WIDTH);
        for (int i = WIDTH - 1; i > x; --i) {
            *(row + i) = *(row + i - 1);
        }
        *(row + x) = piece;
    }
}

void Juego::removePiece(int x, int y) {
    if (y < HEIGHT && x < WIDTH) {
        char* row = board.data()->data() + (y * WIDTH);
        for (int i = x; i < WIDTH - 1; ++i) {
            *(row + i) = *(row + i + 1);
        }
        *(row + WIDTH - 1) = EMPTY;
    }
}

std::string Juego::toLowerCase(const std::string& str) {
    std::string lowerStr = str;
    for (char& c : lowerStr) {
        c = tolower(c);
    }
    return lowerStr;
}

void Juego::iniciar(ListaSimple<std::string>& lista) {
    int totalLength = 0;
    NodoSimple<std::string>* aux = lista.getPrimero();
    while (aux != nullptr) {
        std::string nombre = toLowerCase(aux->getPrimerNombre());
        totalLength += nombre.length() + 1;
        aux = aux->getSiguiente();
    }

    if (totalLength > WIDTH) {
        WIDTH = totalLength;
        board.resize(HEIGHT, vector<char>(WIDTH, EMPTY));
    }

    initializeBoard();
    aux = lista.getPrimero();
    int y = HEIGHT - 1;
    int x = (WIDTH - totalLength) / 2; // Centrar el texto

    while (aux != nullptr && x < WIDTH) {
        std::string nombre = toLowerCase(aux->getPrimerNombre());
        for (char c : nombre) {
            if (x < WIDTH) {
                *(board.data()->data() + (y * WIDTH) + x) = c;
                x++;
            }
        }
        if (x < WIDTH) {
            *(board.data()->data() + (y * WIDTH) + x) = EMPTY;
            x++;
        }
        aux = aux->getSiguiente();
    }

    srand(time(0));
    char pieza = 'a' + rand() % 26;
    int posX = WIDTH / 2, posY = 0;

    bool jugando = true;
    DWORD lastMoveTime = GetTickCount();
    bool fastDrop = false;

    while (jugando) {
        if (_kbhit()) {
            char tecla = _getch();
            if (tecla == 27) {
                jugando = false;
                break;
            }

            gotoxySimple(posX, posY);
            cout << EMPTY;

            switch (tecla) {
                case 75:
                    if (posX > 0 && *(board.data()->data() + (posY * WIDTH) + (posX - 1)) == EMPTY) posX--;
                    break;
                case 77:
                    if (posX < WIDTH - 1 && *(board.data()->data() + (posY * WIDTH) + (posX + 1)) == EMPTY) posX++;
                    break;
                case 80:
                    fastDrop = true;
                    break;
            }

            gotoxySimple(posX, posY);
            cout << pieza;
        }

        Sleep(100);

        if (fastDrop || GetTickCount() - lastMoveTime >= 1000) {
            lastMoveTime = GetTickCount();
            fastDrop = false;

            if (!checkCollision(posX, posY + 1)) {
                gotoxySimple(posX, posY);
                cout << EMPTY;
                posY++;
            } else {
                if (posY + 1 < HEIGHT && *(board.data()->data() + ((posY + 1) * WIDTH) + posX) == pieza) {
                    removePiece(posX, posY + 1);
                    gotoxySimple(posX, posY + 1);
                    cout << EMPTY;
                } else {
                    mergePiece(pieza, posX, posY);
                }
                for (int row = HEIGHT - 2; row >= 0; --row) {
                    for (int col = 0; col < WIDTH; ++col) {
                        if (*(board.data()->data() + (row * WIDTH) + col) != EMPTY && *(board.data()->data() + ((row + 1) * WIDTH) + col) == EMPTY) {
                            int tempRow = row;
                            while (tempRow + 1 < HEIGHT && *(board.data()->data() + ((tempRow + 1) * WIDTH) + col) == EMPTY) {
                                *(board.data()->data() + ((tempRow + 1) * WIDTH) + col) = *(board.data()->data() + (tempRow * WIDTH) + col);
                                *(board.data()->data() + (tempRow * WIDTH) + col) = EMPTY;
                                tempRow++;
                            }
                        }
                    }
                }

                pieza = 'a' + rand() % 26;
                posX = WIDTH / 2;
                posY = 0;
                if (checkCollision(posX, posY)) {
                    jugando = false;
                }
            }
        }

        printBoard();
        gotoxySimple(posX + 1, posY + 1);
        cout << pieza;
    }
}
