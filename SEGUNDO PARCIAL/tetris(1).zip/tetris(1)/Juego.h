#ifndef JUEGO_H
#define JUEGO_H

#include <vector>
#include <string>
#include "ListaSimple.h"

class Juego {
public:
    Juego();
    void iniciar(ListaSimple<std::string>& lista);

private:
    int WIDTH;
    int HEIGHT;
    static const char EMPTY;
    std::vector<std::vector<char>> board;

    void initializeBoard();
    void printBoard();
    bool checkCollision(int x, int y);
    void mergePiece(char piece, int x, int y);
    void removePiece(int x, int y);
    void gotoxySimple(int x, int y);
    std::string toLowerCase(const std::string& str);
    void adjustToConsoleSize();
};

#endif // JUEGO_H